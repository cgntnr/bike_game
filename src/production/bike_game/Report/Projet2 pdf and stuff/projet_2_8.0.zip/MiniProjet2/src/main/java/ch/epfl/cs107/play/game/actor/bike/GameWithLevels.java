package ch.epfl.cs107.play.game.actor.bike;

public interface GameWithLevels
{
	public void nextLevel();
	
	public void resetLevel();
}