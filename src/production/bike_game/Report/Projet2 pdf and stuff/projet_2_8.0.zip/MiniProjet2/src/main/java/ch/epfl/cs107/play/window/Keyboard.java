package ch.epfl.cs107.play.window;

/**
 * Represents the keyboard.
 */
public interface Keyboard {
    // TODO put int constants here, instead of using KeyEvent directly?
    
    public Button get(int code);
    
}
