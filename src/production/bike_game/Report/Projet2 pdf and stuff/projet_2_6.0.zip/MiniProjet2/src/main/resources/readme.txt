See https://kenney.nl/assets

